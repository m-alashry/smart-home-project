

#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_
#include "STD_Types.h"


void ADC_vinit(void);


uint16 ADC_u16Read(void);

#endif 